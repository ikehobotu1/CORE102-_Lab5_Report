#!/usr/bin/env python3
import collections
import sys
from pathlib import Path
from scapy.all import PcapReader, IP, TCP, UDP, ICMP

if len(sys.argv) != 2:
    print(f"Usage: {sys.argv[0]} FILE.pcap")
    raise SystemExit(1)

pcap = Path(sys.argv[1])
if not pcap.is_file() or pcap.suffix.lower() not in {'.pcap', '.pcapng'}:
    print("Provide an existing .pcap or .pcapng file")
    raise SystemExit(2)

protocols = collections.Counter()
endpoints = collections.Counter()
tcp_ports = collections.Counter()
packets = 0

with PcapReader(str(pcap)) as reader:
    for packet in reader:
        packets += 1
        if IP in packet:
            endpoints.update([packet[IP].src, packet[IP].dst])
            if TCP in packet:
                protocols['TCP'] += 1
                tcp_ports.update([packet[TCP].sport, packet[TCP].dport])
                if packet[TCP].sport == 53 or packet[TCP].dport == 53:
                    protocols['DNS-TCP'] += 1
            elif UDP in packet:
                protocols['UDP'] += 1
                if packet[UDP].sport == 53 or packet[UDP].dport == 53:
                    protocols['DNS-UDP'] += 1
            elif ICMP in packet:
                protocols['ICMP'] += 1
            else:
                protocols['Other IPv4'] += 1
        else:
            protocols['Non-IPv4'] += 1

print(f"File: {pcap}")
print(f"Packets: {packets}")
print("Protocols:")
for name, count in protocols.most_common():
    print(f"  {name:12} {count}")
print("Top endpoints:")
for address, count in endpoints.most_common(10):
    print(f"  {address:15} {count}")
print("Top TCP ports:")
for port, count in tcp_ports.most_common(10):
    print(f"  {port:5} {count}")
