#!/usr/bin/env bash
set -u

PREFIX="${1:-192.168.56}"
OUT="live_hosts_$(date +%Y%m%d_%H%M%S).txt"

if [[ "$PREFIX" != "192.168.56" ]]; then
    echo "Scope rejected. Authorised prefix: 192.168.56"
    exit 2
fi

start_time=$(date '+%Y-%m-%d %H:%M:%S')
echo "Authorised ICMP sweep of ${PREFIX}.0/24 started at $start_time" | tee "$OUT"

count=0
for host in $(seq 1 254); do
    address="${PREFIX}.${host}"
    if ping -c 1 -W 1 "$address" >/dev/null 2>&1; then
        echo "$address responded" | tee -a "$OUT"
        ((count++))
    fi
done

finish_time=$(date '+%Y-%m-%d %H:%M:%S')
{
    echo "Finished: $finish_time"
    echo "Total responsive hosts: $count"
} | tee -a "$OUT"

echo "Saved: $OUT"
