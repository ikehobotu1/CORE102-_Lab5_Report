#!/usr/bin/env python3
import ipaddress
import socket
import sys
from datetime import datetime

AUTHORISED = ipaddress.ip_network('192.168.56.0/24')
ALL_PORTS = [22, 53, 80, 443, 8080, 8000]

# Parse arguments: support optional target and optional single port
if len(sys.argv) < 2 or len(sys.argv) > 3:
    print(f"Usage: {sys.argv[0]} HOST [PORT]")
    raise SystemExit(1)

try:
    target = ipaddress.ip_address(sys.argv[1])
except ValueError:
    print("Invalid IPv4 address")
    raise SystemExit(2)

if target not in AUTHORISED:
    print(f"Scope rejected. Authorised network: {AUTHORISED}")
    raise SystemExit(3)

ports_to_check = ALL_PORTS
if len(sys.argv) == 3:
    try:
        single_port = int(sys.argv[2])
        if single_port not in ALL_PORTS:
            print(f"Port {single_port} is not in the approved CORE102 port list.")
            raise SystemExit(4)
        ports_to_check = [single_port]
    except ValueError:
        print("Invalid port number")
        raise SystemExit(5)

print(f"CORE102 service check for {target}")
print(f"Started: {datetime.now().isoformat(timespec='seconds')}")

for port in ports_to_check:
    try:
        with socket.create_connection((str(target), port), timeout=1):
            state = "OPEN"
    except (TimeoutError, ConnectionRefusedError, OSError):
        state = "CLOSED OR FILTERED"
    print(f"TCP {port:5}: {state}")
