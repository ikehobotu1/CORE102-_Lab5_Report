#!/usr/bin/env bash
set -euo pipefail

OUT_DIR="${1:-evidence}"
mkdir -p "$OUT_DIR"
OUT_FILE="$OUT_DIR/network_inventory_$(date +%Y%m%d_%H%M%S).txt"

section() {
    echo
    echo "===== $1 ====="
}

{
    echo "CORE102 NETWORK INVENTORY"
    echo "Generated: $(date --iso-8601=seconds)"
    echo "Host: $(hostname)"
    echo "User: $(whoami)"
    
    section "INTERFACES"
    ip -br link
    ip -br addr
    
    section "ROUTES"
    ip route
    
    section "ROUTING DECISION FOR 192.168.56.1"
    ip route get 192.168.56.1
    
    section "NEIGHBOURS"
    ip neigh show
    
    section "LISTENING SOCKETS"
    ss -tuln
    
    section "RESOLVER"
    cat /etc/resolv.conf
    
    section "DISK SPACE"
    df -h .

} > "$OUT_FILE"

echo "Inventory saved to $OUT_FILE"
